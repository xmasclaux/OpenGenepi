<?php

/**
 * UserAwareness filter form.
 *
 * @package    epi
 * @subpackage filter
 * @author     Your name here
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class UserAwarenessFormFilter extends BaseUserAwarenessFormFilter
{
  public function configure()
  {
  }
}
