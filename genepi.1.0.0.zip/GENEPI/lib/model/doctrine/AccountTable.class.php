<?php

class AccountTable extends Doctrine_Table
{
}
