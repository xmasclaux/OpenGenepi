<?php

class coreConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
