<?php

class mgmtConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
