<h1><?php echo __('New Group')?></h1>

<?php include_partial('groupform', array('form' => $groupform)) ?>
