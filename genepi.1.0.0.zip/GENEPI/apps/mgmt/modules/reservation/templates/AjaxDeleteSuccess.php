
<div class=error_list>
	<li><?php echo __('Reservation deteled'); ?></li>
</div>

<div>
<input type="button" value=<?php echo __('Close')?> onclick="$('#event_detail').dialog('close');">
</div>
