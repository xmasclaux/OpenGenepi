<h1><?php echo __('New Room')?></h1>

<?php include_partial('roomForm', array('form' => $form)) ?>