<h1><?php echo __('Edit Computer')?></h1>

<?php include_partial('computerForm', array('form' => $form, 'culture' => $culture)) ?>