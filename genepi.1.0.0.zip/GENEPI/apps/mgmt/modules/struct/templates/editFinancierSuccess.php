<h1><?php echo __('Edit Financier')?></h1>

<?php include_partial('financierForm', array('form' => $form, 'financier' => $financier)) ?>
