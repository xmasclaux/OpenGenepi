<h1><?php echo __('New building')?></h1>

<?php include_partial('buildingForm', array('form' => $form)) ?>