<?php

class installConfiguration extends sfApplicationConfiguration
{
  public function configure()
  {
  }
}
